const express = require('express');
const router = express.Router();
const Poet = require('../models/Poet');


router.post('/add', async (req, res) => {
  const { name, imageUrl, description } = req.body;
  try {
    const newPoet = new Poet({ name, imageUrl, description });
    await newPoet.save();
    res.status(201).json({ message: 'Poet added successfully' });
  } catch (err) {
    console.error(' Error adding poet:', err); 
    res.status(500).json({ message: 'Error adding poet', error: err.message });
  }
});




router.get('/', async (req, res) => {
  try {
    const poets = await Poet.find();
    res.json(poets);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching poets' });
  }
});


router.put('/:id', async (req, res) => {
  try {
    const updatedPoet = await Poet.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedPoet);
  } catch (err) {
    res.status(500).json({ message: 'Error updating poet' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    await Poet.findByIdAndDelete(req.params.id);
    res.json({ message: 'Poet deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error deleting poet' });
  }
});

module.exports = router;
