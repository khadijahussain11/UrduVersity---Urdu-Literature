const express = require('express');
const router = express.Router();
const Ghazal = require('../models/Ghazal');


router.post('/add', async (req, res) => {
  const { title, poet, description } = req.body;
  try {
    const newGhazal = new Ghazal({ title, poet, description });
    await newGhazal.save();
    res.status(201).json({ message: 'Ghazal added successfully' });
  } catch (err) {
    console.error('Error adding ghazal:', err.message); 
    res.status(500).json({ message: 'Error adding ghazal', error: err.message });
  }
});



router.get('/', async (req, res) => {
  try {
    const ghazals = await Ghazal.find();
    res.json(ghazals);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching ghazals' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const updatedGhazal = await Ghazal.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedGhazal);
  } catch (err) {
    res.status(500).json({ message: 'Error updating ghazal' });
  }
});


router.delete('/:id', async (req, res) => {
  try {
    await Ghazal.findByIdAndDelete(req.params.id);
    res.json({ message: 'Ghazal deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error deleting ghazal' });
  }
});

module.exports = router;
