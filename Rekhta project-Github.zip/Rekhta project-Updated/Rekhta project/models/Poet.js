const mongoose = require('mongoose');

const poetSchema = new mongoose.Schema({
  name: { type: String, required: true },
  imageUrl: {
    type: String,
  },
  description: { type: String, required: true }
});

module.exports = mongoose.model('Poet', poetSchema);
