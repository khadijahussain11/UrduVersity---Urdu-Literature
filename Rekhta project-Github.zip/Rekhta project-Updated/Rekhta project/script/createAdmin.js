// scripts/createAdmin.js
const mongoose = require('mongoose');
const Admin = require('../models/Admin');

mongoose.connect('mongodb://127.0.0.1:27017/urduversity', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(async () => {
  await Admin.create({ username: 'admin', password: 'admin123' });
  console.log('Admin user created');
  process.exit();
});
