let editingPoetId = null;
const BASE_URL = 'http://localhost:3000';

window.onload = function () {
  fetchPoets();
  document.getElementById('poetForm').addEventListener('submit', savePoet);
};

async function fetchPoets() {
  try {
    const res = await fetch(`${BASE_URL}/api/poets`);
    const poets = await res.json();
    displayPoets(poets);
  } catch (error) {
    console.error('Failed to fetch poets:', error);
  }
}

function displayPoets(poets) {
  const container = document.getElementById('poetList');
  container.innerHTML = '';

  poets.forEach(poet => {
    const div = document.createElement('div');
    div.innerHTML = `
      <h3>${poet.name}</h3>
      <img src="${poet.imageUrl}" alt="${poet.name}" width="100">
  
      <p>${poet.description}</p>
      <button onclick='editPoet(${JSON.stringify(poet._id)}, ${JSON.stringify(poet.name)}, ${JSON.stringify(poet.imageUrl)}, ${JSON.stringify(poet.description)})'>Edit</button>
      <button onclick="deletePoet('${poet._id}')">Delete</button>
      
    `;
    container.appendChild(div);
  });
}

function showAddForm() {
  editingPoetId = null;
  document.getElementById('formTitle').textContent = 'Add Poet';
  document.getElementById('poetForm').style.display = 'block';
  document.getElementById('name').value = '';
  document.getElementById('imageUrl').value = '';
  document.getElementById('description').value = '';
}

function cancelEdit() {
  editingPoetId = null;
  document.getElementById('poetForm').style.display = 'none';
}

function editPoet(id, name, imageUrl, description) {
  editingPoetId = id;
  document.getElementById('formTitle').textContent = 'Edit Poet';
  document.getElementById('poetForm').style.display = 'block';
  document.getElementById('name').value = name;
  document.getElementById('imageUrl').value = imageUrl;
  document.getElementById('description').value = description;
}



async function savePoet(event) {
      event.preventDefault();

      const name = document.getElementById('name').value.trim();
      const imageUrl = document.getElementById('imageUrl').value.trim();
      const description = document.getElementById('description').value.trim();

      const data = { name, imageUrl, description };

      try {
        const endpoint = editingPoetId
          ? `${BASE_URL}/api/poets/${editingPoetId}`
          : `${BASE_URL}/api/poets/add`;

        const method = editingPoetId ? 'PUT' : 'POST';

        const res = await fetch(endpoint, {
          method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });

        const result = await res.json();

        if (!res.ok) {
          throw new Error(result.message || 'Failed to save poet');
        }

        cancelEdit();
        fetchPoets();
      } catch (error) {
        console.error('Error saving poet:', error);
        alert('Failed to save poet.');
      }
    }

async function deletePoet(id) {
  if (confirm('Are you sure you want to delete this poet?')) {
    try {
      await fetch(`${BASE_URL}/api/poets/${id}`, {
        method: 'DELETE'
      });
      fetchPoets();
    } catch (error) {
      console.error('Error deleting poet:', error);
    }
  }
}
