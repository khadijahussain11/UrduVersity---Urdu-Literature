document.getElementById('adminLoginForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  const errorMsg = document.getElementById('error');

  try {
    const res = await fetch('http://localhost:3000/admin/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    });

    const data = await res.json();

    if (res.ok) {
    
      alert('Login successful');
      window.location.href = 'admin-dashboard.html';
    } else {
      errorMsg.textContent = data.message || 'Login failed';
    }
  } catch (err) {
    errorMsg.textContent = 'Network error';
  }
});



async function setupDictionarySearch() {
  const input = document.getElementById("dictSearchInput");
  const suggestions = document.getElementById("dictSuggestions");
  const button = document.getElementById("dictSearchBtn");

  
  async function fetchMeaning(word) {
    suggestions.innerHTML = "";

    if (!word || word.length < 2) return;

    try {
      const res = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
      if (!res.ok) {
        suggestions.innerHTML = "<div class='suggestion-item'>No meaning found</div>";
        return;
      }

      const data = await res.json();

    
      const meanings = data[0].meanings[0].definitions.slice(0, 3);

      meanings.forEach(def => {
        const div = document.createElement("div");
        div.classList.add("suggestion-item");
        div.innerHTML = `<strong>${word}</strong>: ${def.definition}`;
        suggestions.appendChild(div);
      });
    } catch (error) {
      console.error(error);
      suggestions.innerHTML = "<div class='suggestion-item'>Error fetching meaning</div>";
    }
  }

  
  input.addEventListener("input", () => {
    const query = input.value.trim();
    fetchMeaning(query);
  });

  button.addEventListener("click", () => {
    const query = input.value.trim();
    fetchMeaning(query);
  });
}

setupDictionarySearch();

