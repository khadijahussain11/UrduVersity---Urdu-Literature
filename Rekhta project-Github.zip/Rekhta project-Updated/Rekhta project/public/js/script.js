const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

menuToggle.addEventListener("click", () => {
  navLinks.classList.toggle("active");
});



  document.getElementById("searchBtn").addEventListener("click", function () {
    const query = document.getElementById("searchInput").value.trim();

    if (!query) {
      alert("Please enter a search term.");
      return;
    }

    alert("You searched for: " + query);
  });

  document.getElementById("searchInput").addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      document.getElementById("searchBtn").click();
    }
  });





const ghazals = {
  1: {
    title: "Yaad Ki Rahguzar Mein",
    urdu: `یاد کی رہگزر میں اب بھی کہیں، کوئی خواب چپکے سے چلتا ہے
خواب وہ جو کبھی سچ نہ ہو سکا، مگر دل کو بہلاتا ہے
وقت کے ساتھ وہ چپ سا گیا، مگر یادوں میں آتا ہے`,
     roman: `Yaad ki rahguzar mein ab bhi kahin, koi khwab chupke se chalta hai  
Khwab woh jo kabhi sach na ho saka, magar dil ko behlata hai  
Waqt ke saath woh chup sa gaya, magar yaadon mein aata hai`
  },
  2: {
    title: "Chaandni Raato Ki Baat",
    urdu: `چاندنی راتوں کی بات کچھ اور ہی ہوتی ہے
خاموشیوں میں چھپی محبت کی بات ہوتی ہے
رات کی خامشی میں وہ لمحہ، جب دل بے ساختہ رو دیتا ہے`,
    roman: `Chaandni raato ki baat kuch aur hi hoti hai  
Khamoshiyon mein chhupi mohabbat ki baat hoti hai  
Raat ki khamoshi mein woh lamha, jab dil besakhta ro deta hai`
  },
  3: {
    title: "Tanhaayi Ke Saaye Mein",
    urdu: `تنہائی کے سائے میں دل بہت کچھ کہتا ہے
سناٹے میں چھپی صدائیں، روح تک رستی ہیں
خواب ادھورے، یادیں پرانی، سب ایک کہانی کہتے ہیں`,
     roman: `Tanhaayi ke saaye mein dil bohat kuch kehta hai  
Sanate mein chhupi sadaayein, rooh tak rasti hain  
Khwab adhoore, yaadein purani, sab ek kahani kehte hain`
  }
};


function showFullGhazal(id) {
  const modal = document.getElementById('ghazal-modal');
  document.getElementById('full-ghazal-title').innerText = ghazals[id].title;
  document.getElementById('full-ghazal-urdu').innerText = ghazals[id].urdu;
  document.getElementById('full-ghazal-roman').innerText = ghazals[id].roman;
  modal.style.display = 'flex';
}

function closeGhazal() {
  document.getElementById('ghazal-modal').style.display = 'none';
}

window.onclick = function (event) {
  const modal = document.getElementById('ghazal-modal');
  if (event.target === modal) {
    modal.style.display = 'none';
  }
};


 function openPoetModal(id) {
    document.getElementById(id).style.display = "block";
  }

  function closePoetModal(id) {
    document.getElementById(id).style.display = "none";
  }


  window.onclick = function(event) {
    const modals = document.querySelectorAll(".poet-modal");
    modals.forEach(modal => {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    });
  };


  function downloadPDF(filePath) {
  const link = document.createElement('a');
  link.href = filePath;
  link.download = filePath.split('/').pop();
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}


/* search*/
const searchInput = document.getElementById("searchInput");
const suggestionsBox = document.getElementById("suggestions");
const searchBtn = document.getElementById("searchBtn");

const searchableItems = [];
document.querySelectorAll("h1, h2, h3, p").forEach(el => {
  searchableItems.push({
    text: el.textContent.trim(),
    element: el
  });
});


searchInput.addEventListener("input", () => {
  const query = searchInput.value.toLowerCase();
  suggestionsBox.innerHTML = "";

  if (query.length === 0) {
    suggestionsBox.style.display = "none";
    return;
  }

  const filtered = searchableItems.filter(item =>
    item.text.toLowerCase().includes(query)
  );

  if (filtered.length === 0) {
    suggestionsBox.innerHTML = "<div>No results found</div>";
  } else {
    filtered.slice(0, 6).forEach(item => { 
      const div = document.createElement("div");
      div.textContent = item.text;
      div.onclick = () => {
        searchInput.value = item.text;
        suggestionsBox.style.display = "none";
        highlightText(item.text);
        item.element.scrollIntoView({ behavior: "smooth", block: "center" });
      };
      suggestionsBox.appendChild(div);
    });
  }

  suggestionsBox.style.display = "block";
});


searchBtn.addEventListener("click", () => {
  highlightText(searchInput.value);
});


function highlightText(query) {
  if (!query) return;

  
  document.querySelectorAll("mark").forEach(el => {
    el.replaceWith(el.textContent);
  });

  searchableItems.forEach(item => {
    const regex = new RegExp(`(${query})`, "gi");
    item.element.innerHTML = item.element.textContent.replace(
      regex,
      "<mark style='background:yellow;'>$1</mark>"
    );
  });
}

async function setupDictionarySearch() {
  const input = document.getElementById("dictSearchInput");
  const suggestions = document.getElementById("dictSuggestions");
  const button = document.getElementById("dictSearchBtn");

  
  async function fetchMeaning(word) {
    suggestions.innerHTML = "";

    if (!word || word.length < 2) return;

    try {
      const res = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
      if (!res.ok) {
        suggestions.innerHTML = "<div class='suggestion-item'>No meaning found</div>";
        return;
      }

      const data = await res.json();

    
      const meanings = data[0].meanings[0].definitions.slice(0, 3);

      meanings.forEach(def => {
        const div = document.createElement("div");
        div.classList.add("suggestion-item");
        div.innerHTML = `<strong>${word}</strong>: ${def.definition}`;
        suggestions.appendChild(div);
      });
    } catch (error) {
      console.error(error);
      suggestions.innerHTML = "<div class='suggestion-item'>Error fetching meaning</div>";
    }
  }

  
  input.addEventListener("input", () => {
    const query = input.value.trim();
    fetchMeaning(query);
  });

  button.addEventListener("click", () => {
    const query = input.value.trim();
    fetchMeaning(query);
  });
}

setupDictionarySearch();

